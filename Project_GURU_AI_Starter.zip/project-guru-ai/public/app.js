const $ = (id) => document.getElementById(id);
let currentUser = null;
let authMode = "register";

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 3200);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options, credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(data.error || "Something went wrong."); error.status = response.status; error.data = data; throw error; }
  return data;
}
function showAuth(mode) {
  authMode = mode;
  $("authModal").classList.remove("hidden");
  $("modalTitle").textContent = mode === "register" ? "Welcome to GURU AI" : "Welcome back";
  $("modalSubtitle").textContent = mode === "register" ? "Create your account to get your first 2 tutor questions free." : "Log in to continue your learning journey.";
  $("nameField").classList.toggle("hidden", mode === "login");
  $("name").required = mode === "register";
  $("password").autocomplete = mode === "register" ? "new-password" : "current-password";
  $("authSubmit").innerHTML = mode === "register" ? 'Create account <span>→</span>' : 'Log in <span>→</span>';
  $("switchAuth").textContent = mode === "register" ? "Already have an account? Log in" : "New to GURU AI? Create an account";
  $("authError").textContent = "";
}
function closeAuth() { $("authModal").classList.add("hidden"); }
function updateProfile(user) {
  currentUser = user;
  $("loginOpen").classList.toggle("hidden", !!user);
  $("signupOpen").classList.toggle("hidden", !!user);
  $("logoutBtn").classList.toggle("hidden", !user);
  $("usagePill").classList.toggle("hidden", !user);
  if (!user) {
    $("usagePill").textContent = "2 free questions";
    $("planName").textContent = "Free learner";
    $("planUsage").textContent = "Sign in to start your 2 free questions";
    $("question").placeholder = "Sign in to use your free questions…";
    return;
  }
  $("board").value = user.board;
  $("classLevel").value = user.classLevel;
  $("language").value = user.language;
  $("chatClass").textContent = `CLASS ${user.classLevel}`;
  $("planName").textContent = user.plan === "plus" ? "GURU Plus" : "Free learner";
  $("planUsage").textContent = user.plan === "plus" ? "Plus access active" : `${user.freeUsesRemaining} free questions remaining`;
  $("usagePill").textContent = user.plan === "plus" ? "GURU Plus" : `${user.freeUsesRemaining} free left`;
  $("question").placeholder = user.plan === "plus" ? "Ask your doubt…" : "Ask your doubt… (2 free questions)";
}
function addMessage(role, content) {
  const row = document.createElement("div"); row.className = `message ${role}`;
  if (role === "assistant") {
    const avatar = document.createElement("div"); avatar.className = "message-avatar"; avatar.textContent = "✳"; row.appendChild(avatar);
  }
  const bubble = document.createElement("div"); bubble.className = "bubble";
  // textContent prevents model output from being interpreted as HTML.
  bubble.textContent = content;
  row.appendChild(bubble); $("chatMessages").appendChild(row);
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
}
function setBusy(busy) {
  $("question").disabled = busy; $("chatForm").querySelector("button").disabled = busy;
  $("chatForm").querySelector("button").textContent = busy ? "…" : "↑";
}
async function sendQuestion(text) {
  if (!currentUser) { showAuth("register"); return; }
  const question = (text || $("question").value).trim();
  if (!question) return;
  $("question").value = ""; $("composerCount").textContent = "0 / 2000";
  $("suggestions").classList.add("hidden");
  addMessage("user", question); setBusy(true);
  const loading = document.createElement("div"); loading.className = "message assistant";
  const av = document.createElement("div"); av.className = "message-avatar"; av.textContent = "✳";
  const bub = document.createElement("div"); bub.className = "bubble"; bub.textContent = "Thinking through this with you…";
  loading.append(av,bub); $("chatMessages").appendChild(loading);
  try {
    const data = await api("/api/chat", { method: "POST", body: JSON.stringify({ message: question }) });
    loading.remove(); addMessage("assistant", data.reply); updateProfile(data.user);
  } catch (error) {
    loading.remove();
    if (error.status === 402) {
      addMessage("assistant", "You've used your 2 free tutor questions. GURU Plus is planned for expanded access. Paid checkout is not enabled in this preview, so you won't be charged.");
      toast("You've reached the free preview limit.");
    } else addMessage("assistant", error.message);
  } finally { setBusy(false); }
}
async function loadHistory() {
  try {
    const data = await api("/api/history");
    if (data.messages?.length) {
      $("chatMessages").innerHTML = "";
      data.messages.forEach(m => addMessage(m.role, m.content));
      $("suggestions").classList.add("hidden");
    }
  } catch {}
}
async function boot() {
  try { const data = await api("/api/me"); updateProfile(data.user); await loadHistory(); }
  catch { updateProfile(null); }
}
$("loginOpen").addEventListener("click", () => showAuth("login"));
$("signupOpen").addEventListener("click", () => showAuth("register"));
$("heroStart").addEventListener("click", () => currentUser ? $("app").scrollIntoView({behavior:"smooth"}) : showAuth("register"));
$("modalClose").addEventListener("click", closeAuth);
$("authModal").addEventListener("click", e => { if (e.target === $("authModal")) closeAuth(); });
$("switchAuth").addEventListener("click", () => showAuth(authMode === "register" ? "login" : "register"));
$("authForm").addEventListener("submit", async e => {
  e.preventDefault(); $("authError").textContent = "";
  const payload = { email: $("email").value, password: $("password").value };
  if (authMode === "register") Object.assign(payload, {
    name: $("name").value, board: $("board").value,
    classLevel: $("classLevel").value, language: $("language").value
  });
  try {
    const data = await api(`/api/auth/${authMode}`, { method:"POST", body:JSON.stringify(payload) });
    updateProfile(data.user); closeAuth(); toast(authMode === "register" ? "Your GURU AI account is ready!" : "You're logged in!");
    await loadHistory();
  } catch (error) { $("authError").textContent = error.message; }
});
$("logoutBtn").addEventListener("click", async () => {
  await api("/api/auth/logout", {method:"POST",body:"{}"}); updateProfile(null);
  $("chatMessages").innerHTML = ""; addMessage("assistant", "You've logged out. Sign in whenever you're ready to learn again.");
  toast("Logged out safely.");
});
$("chatForm").addEventListener("submit", e => { e.preventDefault(); sendQuestion(); });
$("question").addEventListener("input", () => $("composerCount").textContent = `${$("question").value.length} / 2000`);
document.querySelectorAll(".suggestion").forEach(btn => btn.addEventListener("click", () => sendQuestion(btn.textContent)));
$("upgradeBtn").addEventListener("click", () => toast("GURU Plus early access and pricing are coming after the pilot."));
$("freePlanBtn").addEventListener("click", () => toast("Your free plan includes 2 tutor questions per account."));
$("board").addEventListener("change", () => toast("Profile changes apply to new accounts in this prototype."));
$("classLevel").addEventListener("change", () => $("chatClass").textContent = `CLASS ${$("classLevel").value}`);
boot();
