require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env (at least 32 characters).");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(process.env.DB_FILE || path.join(dataDir, "guru.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    board TEXT NOT NULL DEFAULT 'CBSE',
    class_level TEXT NOT NULL DEFAULT '12',
    preferred_language TEXT NOT NULL DEFAULT 'English',
    plan TEXT NOT NULL DEFAULT 'free',
    free_uses INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, id);
`);

const publicUser = (u) => ({
  id: u.id, name: u.name, email: u.email, board: u.board,
  classLevel: u.class_level, language: u.preferred_language,
  plan: u.plan, freeUses: u.free_uses,
  freeUsesRemaining: Math.max(0, 2 - u.free_uses)
});

function signToken(user) {
  return jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "7d" });
}
function setAuthCookie(res, token) {
  res.cookie("guru_token", token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "lax", maxAge: 7 * 24 * 60 * 60 * 1000
  });
}
function auth(req, res, next) {
  try {
    const token = req.cookies.guru_token;
    if (!token) return res.status(401).json({ error: "Please sign in to continue." });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(payload.sub);
    if (!user) return res.status(401).json({ error: "Account not found. Please sign in again." });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: "Your session expired. Please sign in again." });
  }
}

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: "30kb" }));
app.use(cookieParser());
app.use("/api", rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false }));

app.post("/api/auth/register", rateLimit({ windowMs: 15 * 60 * 1000, limit: 8 }), async (req, res) => {
  const { name, email, password, board, classLevel, language } = req.body || {};
  if (!name || name.trim().length < 2 || name.trim().length > 60)
    return res.status(400).json({ error: "Enter a name between 2 and 60 characters." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "")))
    return res.status(400).json({ error: "Enter a valid email address." });
  if (typeof password !== "string" || password.length < 10 || password.length > 100)
    return res.status(400).json({ error: "Password must be 10–100 characters." });

  const allowedBoards = ["CBSE", "Bihar Board", "ICSE", "ISC", "State Board", "Other"];
  const allowedClasses = ["11", "12"];
  const allowedLanguages = ["English", "Hindi", "Hinglish", "Bengali", "Marathi", "Tamil", "Telugu", "Other"];
  const safeBoard = allowedBoards.includes(board) ? board : "CBSE";
  const safeClass = allowedClasses.includes(String(classLevel)) ? String(classLevel) : "12";
  const safeLanguage = allowedLanguages.includes(language) ? language : "English";

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare(`
      INSERT INTO users (name,email,password_hash,board,class_level,preferred_language)
      VALUES (?,?,?,?,?,?)
    `).run(name.trim(), email.trim().toLowerCase(), hash, safeBoard, safeClass, safeLanguage);
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
    setAuthCookie(res, signToken(user));
    res.status(201).json({ user: publicUser(user) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "That email is already registered." });
    res.status(500).json({ error: "Could not create your account." });
  }
});

app.post("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(String(email || "").trim().toLowerCase());
  if (!user || !(await bcrypt.compare(String(password || ""), user.password_hash)))
    return res.status(401).json({ error: "Email or password is incorrect." });
  setAuthCookie(res, signToken(user));
  res.json({ user: publicUser(user) });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("guru_token", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  res.json({ ok: true });
});

app.get("/api/me", auth, (req, res) => res.json({ user: publicUser(req.user) }));

app.get("/api/history", auth, (req, res) => {
  const rows = db.prepare("SELECT role, content, created_at FROM messages WHERE user_id = ? ORDER BY id DESC LIMIT 30")
    .all(req.user.id).reverse();
  res.json({ messages: rows });
});

const SYSTEM_PROMPT = `You are GURU AI, a careful and encouraging tutor for Indian Class 11 and 12 students.
Teach rather than merely giving answers. Use the student's selected board, class, subject and language.
Explain step by step, define terms, use a simple example, and finish with one short check-your-understanding question when appropriate.
Do not claim certainty about syllabus details you do not know. If unsure, say so and ask for the chapter or textbook context.
Do not fabricate citations, textbook page numbers, exam predictions, or guaranteed marks. Keep explanations age-appropriate.
If a question is outside education, respond briefly and guide the student back to safe learning.`;

async function generateTutorReply(user, question) {
  const apiKey = process.env.AI_API_KEY;
  if (!apiKey) {
    return "GURU AI is in setup mode. Your account and free-use system are working, but the AI model is not connected yet. The project owner needs to add an AI_API_KEY in the server's .env file. Never add that key to browser code.";
  }
  const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const response = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.AI_MODEL || "gpt-4o-mini",
      temperature: 0.35,
      messages: [
        { role: "system", content: `${SYSTEM_PROMPT}\nStudent profile: Board=${user.board}; Class=${user.class_level}; Preferred language=${user.preferred_language}.` },
        { role: "user", content: question }
      ]
    }),
    signal: AbortSignal.timeout(45000)
  });
  if (!response.ok) {
    const detail = await response.text();
    console.error("AI provider error:", response.status, detail.slice(0, 500));
    throw new Error("The tutor is temporarily unavailable. Please try again shortly.");
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content?.trim() || "I couldn't prepare an explanation. Please try asking in a different way.";
}

app.post("/api/chat", auth, async (req, res) => {
  const question = String(req.body?.message || "").trim();
  if (!question || question.length > 2000)
    return res.status(400).json({ error: "Write a question (maximum 2,000 characters)." });

  const freshUser = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (freshUser.plan !== "plus" && freshUser.free_uses >= 2) {
    return res.status(402).json({
      code: "FREE_LIMIT_REACHED",
      error: "You've used your 2 free tutor questions. GURU Plus will unlock more learning time."
    });
  }

  try {
    const reply = await generateTutorReply(freshUser, question);
    const insert = db.prepare("INSERT INTO messages (user_id,role,content) VALUES (?,?,?)");
    const transaction = db.transaction(() => {
      insert.run(freshUser.id, "user", question);
      insert.run(freshUser.id, "assistant", reply);
      if (freshUser.plan !== "plus") db.prepare("UPDATE users SET free_uses = free_uses + 1 WHERE id = ?").run(freshUser.id);
    });
    transaction();
    const updated = db.prepare("SELECT * FROM users WHERE id = ?").get(freshUser.id);
    res.json({ reply, user: publicUser(updated) });
  } catch (e) {
    res.status(502).json({ error: e.message || "Tutor service error." });
  }
});

app.get("/api/plans", (req, res) => {
  res.json({
    plans: [
      { id: "free", name: "Free", price: 0, description: "2 tutor questions per account" },
      { id: "plus", name: "GURU Plus", price: null, description: "Expanded tutor access, quizzes and study tools", availability: "Coming soon" }
    ],
    paymentsEnabled: false
  });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`GURU AI running at http://localhost:${PORT}`));
