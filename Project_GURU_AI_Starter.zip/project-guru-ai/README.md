# Project GURU AI — Full-stack starter

A mobile-first AI tutor web app with HTML, CSS, JavaScript, Express, SQLite, account registration/login, server-side free-use limits, chat history, and an optional OpenAI-compatible model connection.

## Requirements
- Node.js 20+
- An AI API key for live AI answers (optional while testing the interface)

## Run locally
1. Extract the ZIP.
2. Open the project folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `JWT_SECRET` to a long random value (32+ characters).
6. Optionally set `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL`.
7. Run `npm start`.
8. Open `http://localhost:3000`.

If no AI key is configured, account creation and usage limits work, but the tutor clearly displays setup mode rather than pretending to generate AI answers.

## Included
- Responsive landing page and tutor workspace
- Register / login / logout
- Password hashing with bcrypt
- HttpOnly session cookie using JWT
- SQLite database created automatically in `data/guru.sqlite`
- First 2 successful tutor questions free per account
- Server-side enforcement of the free limit
- Chat history per account
- AI provider key stays on the server
- API rate limiting and Helmet security headers
- GURU Plus plan presentation (checkout intentionally not enabled)

## Important next steps before public launch
1. Add email verification, password reset, account deletion, consent/privacy pages, CSRF protection, stronger abuse controls, and automated tests.
2. Add a vetted curriculum retrieval layer (RAG) with properly licensed/authorised material.
3. Have subject teachers and fluent speakers review answers in each board/language.
4. Add a payment provider only after checking its current India requirements, adult account/KYC eligibility, tax/compliance obligations, refunds, and subscription cancellation rules. Keep payments in sandbox/test mode until the business is ready.
5. Add database backups, monitoring, error reporting, and production hosting.
6. Do not collect student data you do not need. For minors, design age-appropriate privacy and obtain appropriate parental/school permissions where required.

## Architecture
Browser (HTML/CSS/JS) -> Express API -> SQLite + AI provider.
The AI provider is called from the server. Never expose `AI_API_KEY` in browser JavaScript.

## Free-use behaviour
The first two successful tutor requests are counted. The backend checks and increments the counter; changing browser code cannot bypass the server-side limit. Paid status is stored as a plan field, but no endpoint in this starter grants paid access. That must only happen after verified payment or an authorised administrative process.
